<?php
// array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';
	
// connecting to db
$db = new DB_CONNECT();
		
$result = mysql_query("SELECT * FROM user_login");


/*
$Alldetails = mysql_fetch_array($result);
$get_output =  $Alldetails["table_no"];
echo  $get_output;
*/

if(mysql_num_rows($result))
{
	$response['details'] = array();
	while($Alldetails = mysql_fetch_array($result))
	{
		// temp user array
		$details = array();
		$details = $Alldetails;			
		array_push($response['details'],$details);
	}
	
	$response["success"] = 1;
	echo json_encode($response);
}
else 
{
	// unsuccess
	$response["success"] = 0;
	// echoing JSON response
	echo json_encode($response);
}	
?>