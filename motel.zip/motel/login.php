<?php

$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();

$data = json_decode(file_get_contents("php://input"));

$get_name =   mysql_real_escape_string($data->log_name);
$get_email =   mysql_real_escape_string($data->log_email);
$get_password= mysql_real_escape_string($data->log_pass);

// get customer email from admin_login
$result = mysql_query("SELECT * FROM user_login WHERE 
			user_name = '$get_name' AND  user_email = '$get_email' AND 
			user_pass = '$get_password'   ");

// check for empty result
if(mysql_num_rows($result))
{
	$response["success"] = 1;
	
	echo json_encode($response);
}
else 
{
	// unsuccess
	$response["success"] = 0;
	
	// echoing JSON response
	echo json_encode($response);
}	
?>