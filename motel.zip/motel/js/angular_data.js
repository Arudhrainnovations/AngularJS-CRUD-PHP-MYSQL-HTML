var app = angular.module("mymot", ['ngCookies']);
app.controller("mymotelCtrl", function($scope, $http, $cookieStore, $cookies) 
{
	$scope.login_index = function() 
	{
		window.location="index.html";
		return;
	}
	
	$scope.login_index = function() 
	{
		window.location="index.html";
		return;
	}
	
	$scope.register_index = function() 
	{
		window.location="register.html";
		return;
	}
	
	$scope.register_index = function() 
	{
		window.location="order_food.html";
		return;
	}
	
	
	$http.get('get_info.php')
	.success(function (data) 
	{
		$scope.all_order_details = data.details;
	});
	

	
	/************************* login *****************************/
	
	$scope.login = function() 
	{
		$http.post('login.php',
		{
		'log_name':$scope.log_name,'log_email':$scope.log_email, 
		'log_pass':$scope.log_pass
		})	
		.success(function(data, status, headers, config)
		{
			
			if(data.success == 1)
			{
				alert("Welcome");
				window.location = "order_food.html";
				return;
				$cookieStore.put("cook_user_email",$scope.log_email);
			}
			else
			{
				alert("login unsuccessful");
			}
		});
	}
	
	$scope.cook_user_email = $cookieStore.get("cook_user_email");

	/************************** Admin Logout ************************************/
	$scope.admin_logout = function() 
	{
		if(confirm("Are You Sure?"))
		{
			$cookies= "";
			window.location = "index.html";
			return;
		}
		else
		{
			return false;
		}
	}
	
	/************************* admin *****************************/
	
	$scope.admin = function() 
	{
		$http.post('admin_login.php',{'Email':$scope.admin_email, 'Password':$scope.admin_pass})	
		.success(function(data, status, headers, config)
		{
			if(data.success == 1)
			{
				alert("Welcome");
				$cookieStore.put("admin_email",$scope.admin_email);
				window.location = "view.html";
				return;
			}
			else
			{
				alert("login unsuccessful");
			}
		});
	}

	
	/************************* register *****************************/
	
	$scope.register = function() 
	{
		$http.post('register.php',
		{'Name':$scope.reg_name, 'Address':$scope.reg_address,
		'Email':$scope.reg_email, 'Password':$scope.reg_pass, 
		'Phone':$scope.reg_phone
		})	
		.success(function(data, status, headers, config)
		{
			if(data.success == 1)
			{
				alert("registration successful");
				window.location = "index.html";
				return;
			}
			else
			{
				alert("registration unsuccessful");
			}
		});
	}	
	
	
	/************************* order food *****************************/
	 
	$scope.order = function() 
	{
		$http.post('order_food.php',
		{'Tableno':$scope.reg_tableno,
		'Person':$scope.reg_person, 
		'Item1':$scope.reg_item1, 
		'Item2':$scope.reg_item2})	
		.success(function(data, status, headers, config)
		{
			if(data.success == 1)
			{
				alert("food ordered successfully");
				window.location = "view.html";
				return;
			}
			else
			{
				alert("please order food again");
			}
		});
	}
	
	
	/************************** Delete Order  *********************************/
 
	 $scope.order_del = function(food_id) 
	{		
        $http.post('order_del.php', 
		{
		'food_id': food_id
		})
		.success(function(data, status, headers, config) 
		{
		
			if(data.success == 1)
			{
				alert(" Deleted Successfully");
				window.location = "view.html";	
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting order!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }

	
	
	/************************** Update Order *********************************/
	$scope.edit = function(food_id, table_no, person, item_1, item_2) 
	{
		$cookieStore.put("cook_food_id",food_id);
		$cookieStore.put("table_no",table_no);
		$cookieStore.put("person",person);
		$cookieStore.put("item_1",item_1);
		$cookieStore.put("item_2",item_2);
		window.location = "update_order.html";
		return;
	}
	
	$scope.cook_food_id = $cookieStore.get("cook_food_id");
	$scope.table_no = $cookieStore.get("table_no");
	$scope.person = $cookieStore.get("person");
	$scope.item_1 = $cookieStore.get("item_1");
	$scope.item_2 = $cookieStore.get("item_2");
	

$scope.save = function() 
	{
	$http.post('edit_order.php', 
	{
	'food_id': $scope.cook_food_id, 'table_no': $scope.table_no, 
	'person': $scope.person, 'item_1':$scope.item_1, 
	'item_2': $scope.item_2
	})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			alert("Updated Successfully");
			window.location = "view.html"; //create_associate			
			$cookies.cook_food_id = "";
			$cookies.table_no = "";
			return;
		}
		else if(data.success == 0)
			{
				alert("Error While Deleting order!!");
			}
		else
		{
			alert("Fill All Fields");
		}
			
    });
	}
	

});