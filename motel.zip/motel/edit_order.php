<?php
	
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';
	
// connecting to db
$db = new DB_CONNECT();

// check for post data
$data = json_decode(file_get_contents("php://input"));

$get_id = mysql_real_escape_string($data->food_id);
$get_tableno =  mysql_real_escape_string($data->table_no);
$get_person =  mysql_real_escape_string($data->person);
$get_item1 =  mysql_real_escape_string($data->item_1);
$get_item2 = mysql_real_escape_string($data->item_2);


$result = mysql_query("UPDATE order_food SET table_no='$get_tableno', 
					person='$get_person', item_1='$get_item1', 
					item_2='$get_item2'  WHERE food_id ='$get_id'");
	
if($result)
{
	$response["success"] = 1;
	echo json_encode($response);
}
else 
{
	$response["success"] = 0;
	echo json_encode($response);
}
?>