<?php
/*********************
**** Nandhini S *****
**** July 7, 2015 ****
**********************/

/* Following code will match user login credentials */

// array for JSON response
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();

$data = json_decode(file_get_contents("php://input"));

$get_email = mysql_real_escape_string($data->Email);
$get_password = mysql_real_escape_string($data->Password);

// get customer email from admin_login
$result = mysql_query("SELECT * FROM admin_login WHERE admin_email = '$get_email' AND admin_pass = '$get_password'");

// check for empty result
if(mysql_num_rows($result))
{
	// success
	$response["success"] = 1;
	
	// echoing JSON response
	echo json_encode($response);
}
else 
{
	// unsuccess
	$response["success"] = 0;
	
	// echoing JSON response
	echo json_encode($response);
}	
?>