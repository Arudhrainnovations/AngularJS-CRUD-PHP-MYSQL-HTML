-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2016 at 11:33 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `motel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
`admin_id` int(100) NOT NULL,
  `admin_email` varchar(100) COLLATE utf8_bin NOT NULL,
  `admin_pass` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_email`, `admin_pass`) VALUES
(1, 'admin@gmail.com', 'admin@lms');

-- --------------------------------------------------------

--
-- Table structure for table `order_food`
--

CREATE TABLE IF NOT EXISTS `order_food` (
`food_id` int(100) NOT NULL,
  `table_no` varchar(100) COLLATE utf8_bin NOT NULL,
  `person` varchar(100) COLLATE utf8_bin NOT NULL,
  `item_1` varchar(100) COLLATE utf8_bin NOT NULL,
  `item_2` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `order_food`
--

INSERT INTO `order_food` (`food_id`, `table_no`, `person`, `item_1`, `item_2`) VALUES
(1, '1', 'Immanuel', 'chilli sauce', 'chicken biriyani'),
(2, '1', 'Immanuel', 'chilli sauce', 'chicken biriyani'),
(3, '', '', '', ''),
(4, '', '', '', ''),
(5, '01', 'Immanuel', 'Rice', 'Milk'),
(6, '', '', '', ''),
(7, '', '', '', ''),
(8, '45', 'sdasda', 'dsads', 'dsadsd'),
(9, '', '', '', ''),
(10, '', '', '', ''),
(11, '', '', '', ''),
(12, '56', 'gfgf', 'fgdfgdg', 'dgdfgd'),
(27, '56', 'dfds', 'dfdfs', 'fsdfsffd'),
(28, '34', 'fsdfsdf', 'sdfsdfsdf', 'dfdsfsdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
`user_id` int(100) NOT NULL,
  `user_name` varchar(500) COLLATE utf8_bin NOT NULL,
  `user_address` varchar(100) COLLATE utf8_bin NOT NULL,
  `user_email` varchar(500) COLLATE utf8_bin NOT NULL,
  `user_pass` varchar(500) COLLATE utf8_bin NOT NULL,
  `user_phone` varchar(500) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`user_id`, `user_name`, `user_address`, `user_email`, `user_pass`, `user_phone`) VALUES
(1, 'nandhini', '', 'nandhinisiva8@gmail.com', 'nandhini', '9874563210'),
(2, 'revathi', '', 'revathijramadoss@gmail.com', 'revathi', '7896541230'),
(3, 'brindha', '', 'brindhadevi93@gmail.com', 'brindha', '9874563210'),
(5, '', '', 'ian93@rediffmail.com', 'ggdgfgf', ''),
(9, '', '', 'sfsd@gmail.com', 'hghd56', ''),
(28, '', '', 'dr@gmail.com', 'fdfdf', ''),
(29, '', '', 'df@tt.com', 'fddfd', ''),
(30, '', '', 'git@gmail.com', 'fsfdfsd', ''),
(33, 'Immanuel', 'kumbakonam', 'ian93@rediffmail.com', 'gdfgghd', ''),
(36, 'Immanuel', 'Kumbakonam', 'jj93@rediffmail.com', '645654', '09876512');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
 ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `order_food`
--
ALTER TABLE `order_food`
 ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_food`
--
ALTER TABLE `order_food`
MODIFY `food_id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
